
README - Deployment steps and notes
----------------------------------
1) Frontend (Netlify)
 - Upload the 'frontend' folder to Netlify (drag & drop) or connect to a repo.
 - Open frontend/app.js and replace {YOUR_VERCEL_URL_HERE} with your deployed Vercel backend URL, e.g.:
   const VERCEL_URL = "https://geometry-demon-backend.vercel.app";

2) Backend (Vercel)
 - Deploy the 'vercel_backend' folder on Vercel. Each .js file in this folder is an API endpoint:
   /api/levels  -> vercel_backend/levels.js
   /api/players -> vercel_backend/players.js
   /api/submit  -> vercel_backend/submit.js
   /api/admin/login -> vercel_backend/admin_login.js
   /api/admin/pending -> vercel_backend/admin_pending.js
   /api/admin/approve -> vercel_backend/admin_approve.js
   /api/admin/reject -> vercel_backend/admin_reject.js

 - IMPORTANT: On Vercel, set an environment variable ADMIN_PASSWORD to a value you want (or keep the default embedded password).
   Default admin password (embedded) = "derinmercanlove"

3) After deploying backend, copy your Vercel URL and paste it into frontend/app.js where indicated.

4) Admin login:
 - Use the password you chose (or the default).
 - After login you can approve or reject pending submissions.

5) Data persistence:
 - This template stores data in JSON files inside the backend 'data' folder. On serverless platforms this may be ephemeral.
 - For production use, connect a real database (Postgres, MongoDB) and modify the API code accordingly.

Admin account:
 - admin name: DARKPINGGD
 - embedded admin password (if you don't set ENV): derinmercanlove
Site name: Geometry Dash Finland List

